
#ifndef TIPOS_H_INCLUDED
#define TIPOS_H_INCLUDED

typedef enum {NORTE, SUR, ESTE, OESTE} t_Orientacion;

#endif // TIPOS_H_INCLUDED


